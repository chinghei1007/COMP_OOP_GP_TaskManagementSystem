package hk.edu.polyu.comp.comp2021;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Print {
    public static void print() {
        Scanner scanner = new Scanner(System.in);
        int choice;
        String choice2;
        while (true) {
            try {
                Menu.printmenu();
                choice = scanner.nextInt();
                if (choice < 1 || choice > 6) {
                    System.out.println("Error: Please input numbers in range");
                    continue;
                }
                switch (choice) {
                    case 1: // all task
                        printAllTasks();
                        continue;
                    case 2: // simeple task
                        printSimpleTask();
                        continue;
                    case 3: // composite task
                        printCompositeTask();
                        continue;
                    case 4:// one task
                            try {
                                printTaskNameOnly();
                                printOneTask();
                                continue;
                            } catch (Exception e) {
                                System.out.println("Error: Please enter only task name");
                            }
                    
                    case 5:
                        return;

                }
            } catch (Exception e) {
            }
        }

    }

    public static void printCompositeTask() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content = "";
            System.out.println("\nComposite Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                if (data[0].equals("s")) {
                    continue;
                } else if (data.length == 1) {continue;} // skip all the composite tasks
                String[] criteria = new String[data.length - 4];
                String task = data[1];
                String description = data[2];
                String GroupTask = data[3];
                for (int i = 4; i < data.length; i++) {
                    criteria[i - 4] = data[i];
                }
                // print
                System.out.print("\nTask Name: " + task + " ");
                System.out.print("Description: " + description + " ");
                if (GroupTask.equals("")) {
                    System.out.print("Prerequisites: None" + " ");
                } else {
                    System.out.print("Prerequisites: " + GroupTask + " ");
                }
            }
            reader.close();

        } catch (IOException e) {
            System.out.println("File could not be read");
        }

    }

    public static void printSimpleTask() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content;
            System.out.println("Simple Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                if (data[0] == "c") {
                    continue;
                } else if (data.length == 1) {continue;} // skip all the composite tasks
                String task = data[1];
                String description = data[2];
                float duration = Float.parseFloat(data[3]);
                String prerequisite = data[4];
                // print
                System.out.println("\nTask Name: " + task);
                System.out.println("Description: " + description);
                System.out.println("Duration: " + duration);
                if (prerequisite.equals(",")) {
                    System.out.println("Prerequisites: None");
                } else {
                    System.out.println("Prerequisites: " + prerequisite);
                }
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please input any key to continue...");
            scanner.nextLine();
            reader.close();
        } catch (IOException e) {
            System.out.println("File could not be read");
        }
    }

    public static void printSimpleTaskNameOnly() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content;
            System.out.println("Simple Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                String tasktype = data[0];
                if (tasktype.equals("c")) {
                    continue;
                } else if (data.length == 1) {continue;}
                String task = data[1];
                if (tasktype.equals("s")) {
                    tasktype = "Simple ";
                }
                System.out.println(tasktype + "Task: " + task);
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please input any key to continue...");
            scanner.nextLine();
        } catch (IOException e) {
            System.out.println("Error: File could not be read");
        }
    }

    public static void printCompositeTaskNameOnly() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content;
            System.out.println("Composite Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                String tasktype = data[0];
                if (tasktype.equals("s")) {
                    continue;
                }  else if (data.length == 1) {continue;}
                String task = data[1];
                if (tasktype.equals("c")) {
                    tasktype = "Composite ";
                }
                System.out.println(tasktype + "Task: " + task);
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please input any key to continue...");
            scanner.nextLine();
        } catch (IOException e) {
            System.out.println("Error: File could not be read");
        }
    }

    public static void printTaskNameOnly() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content;
            System.out.println("Simple Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                if (data.length == 1) {continue;}
                String tasktype = data[0];
                String task = data[1];
                if (tasktype.equals("s")) {
                    tasktype = "Simple ";
                }  else if (data.length == 1) {continue;}
                else {
                    tasktype = "Composite ";
                }
                System.out.println(tasktype + "Task: " + task);
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("Please input any key to continue...");
            scanner.nextLine();
        } catch (IOException e) {
            System.out.println("Error: File could not be read");
        }
    }

    public static void printAllTasks() {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String content;
            System.out.println("Simple Task");

            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                if (data[0].equals("c")) {
                    continue;
                } else if (data.length == 1) {continue;}
                // if (criticallength < 0) {continue;} //skip all the composite tasks //for soem
                // reason it doesn't work in intellij
                String task = data[1];
                String description = data[2];
                float duration = Float.parseFloat(data[3]);
                String prerequisite = data[4];

                // print
                System.out.print("\nTask Name: " + task + " ");
                System.out.print("Description: " + description + " ");
                System.out.print("Duration: " + duration + " ");
                if (prerequisite.equals(",")) {
                    System.out.print("Prerequisites: None" + " ");
                } else {
                    System.out.print("Prerequisites: " + prerequisite + " ");
                }
                if (data.length > 5) {
                    int i = 5;
                    while (i < data.length) {
                        System.out.println("Criteria " + (i - 4) + ": " + data[i++]);
                    }
                }
            }

            reader.close();

            reader = new BufferedReader(new FileReader("Task.txt"));
            content = "";
            System.out.print("\nComposite Task");
            while ((content = reader.readLine()) != null) {
                String[] data = content.split("\\|");
                int criticallength = data.length - 5;
                if (data[0].equals("s")) {
                    continue;
                } // skip all the composite tasks
                String task = data[1];
                String description = data[2];
                String GroupTask = data[3];
                // print
                System.out.print("\nTask Name: " + task + " ");
                System.out.print("Description: " + description + " ");
                if (GroupTask.equals("")) {
                    System.out.print("Prerequisites: None" + " ");
                } else {
                    System.out.print("Prerequisites: " + GroupTask + " ");
                }
                if (data.length > 5) {
                    int i = 5;
                    while (i < data.length) {
                        System.out.print("Criteria " + (i - 4) + ": " + data[i++]);
                    }
                }
            }
            Scanner scanner = new Scanner(System.in);
            System.out.println("\nPlease input any key to continue...");
            scanner.nextLine();
            reader.close();

        } catch (IOException e) {
            System.out.println("File could not be read");
        }

    }

    public static void printOneTask(String task) {
        try {
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String line;
            if (!task.matches("^[A-Za-z][0-9A-Za-z]{0,7}")) {
                System.out.println("Invalid task name");
                printOneTask();
            }
            if (TextFile.isEmpty("Task.txt")) {
                reader.close();
                return;
            }
            while ((line = reader.readLine()) != null) {                
                String[] data = line.split("\\|");
                if (data.length == 1) {continue;}
                String txttaskName = data[1];
                String tasktype = data[0];
                String writetask = task;

                // if duplicate found
                if (txttaskName.equals(writetask) && tasktype.equals("s")) {
                    System.out.println("Task found");
                    reader.close();
                    String taskName = data[1];
                    String description = data[2];
                    float duration = Float.parseFloat(data[3]);
                    String prerequisite = data[4];

                    // print
                    System.out.println("Name: " + taskName);
                    System.out.println("Description: " + description);
                    System.out.print("Duration: " + duration + " ");
                    if (prerequisite.equals(",")) {
                        System.out.println("Prerequisite: none");
                    } else {
                        System.out.println("Prerequisite: " + prerequisite);
                    }
                    return;

                } // end of duplicate checking
                else if (txttaskName.equals(writetask) && tasktype.equals("s")) {
                    System.out.println("Task found");
                    reader.close();
                    String taskName = data[1];
                    String description = data[2];
                    String GroupTask = data[3];

                    // print
                    System.out.println("Name: " + taskName);
                    System.out.println("Description: " + description);
                    System.out.println("Group Task: " + GroupTask);
                    return;

                } // end of duplicate checking
                else {
                    System.out.println("Task not found");

                }
            }
            ;

        } catch (IOException e) {
            System.out.println("Error: File cannot be read");
        }
    }
    public static void printOneTask() {
        Scanner scanner = new Scanner(System.in);
        String task = "";
        File file = new File("Task.txt");
        System.out.println("Please input the task you wish to find");
        task = scanner.nextLine();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;

            if (!task.matches("^[A-Za-z][0-9A-Za-z]{0,7}")) {
                System.out.println("Invalid task name");
                printOneTask();
            }
            if (TextFile.isEmpty("Task.txt")) {
                reader.close();
                return;
            }
            while ((line = reader.readLine()) != null) {                
                String[] data = line.split("\\|");
                if (data.length == 1) {continue;}
                String txttaskName = data[1];
                String tasktype = data[0];
                String writetask = task;

                // if duplicate found
                if (txttaskName.equals(writetask) && tasktype.equals("s")) {
                    System.out.println("Task found");
                    reader.close();
                    String taskName = data[1];
                    String description = data[2];
                    float duration = Float.parseFloat(data[3]);
                    String prerequisite = data[4];

                    // print
                    System.out.println("Name: " + taskName);
                    System.out.println("Description: " + description);
                    System.out.print("Duration: " + duration + " ");
                    if (prerequisite.equals(",")) {
                        System.out.println("Prerequisite: none");
                    } else {
                        System.out.println("Prerequisite: " + prerequisite);
                    }
                    return;

                } // end of duplicate checking
                else if (txttaskName.equals(writetask) && tasktype.equals("s")) {
                    System.out.println("Task found");
                    reader.close();
                    String taskName = data[1];
                    String description = data[2];
                    String GroupTask = data[3];

                    // print
                    System.out.println("Name: " + taskName);
                    System.out.println("Description: " + description);
                    System.out.println("Group Task: " + GroupTask);
                    return;

                } // end of duplicate checking

            }
            System.out.println("Task not found");

        } catch (IOException e) {
            System.out.println("Error: File cannot be read");
        }
    }

    /*public static void printOneTask() {
        Scanner scanner = new Scanner(System.in);
        String choice = "";
        File file = new File("Task.txt");
        System.out.println("Please input the task you wish to find");
        choice = scanner.nextLine();

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            if (!choice.matches("^[A-Za-z][0-9A-Za-z]{0,7}")) {
                System.out.println("Invalid task name");
                scanner.close();
                printOneTask();
            }
            if (TextFile.isEmpty("Task.txt")) {
                reader.close();
                return;
            }
            while ((line = reader.readLine()) != null) {
                String[] data = line.split("\\|");
                if (data.length == 1) {continue;}
                String txttaskName = data[1];
                String writetask = choice;

                // if duplicate found
                if (data[0].equals("c")) {
                    System.out.println("Composite task itself do not have duration");
                    return;
                }
                else if (txttaskName.equals(writetask)) {
                    System.out.println("Task found");
                    reader.close();
                    float duration = Float.parseFloat(data[3]);

                    // print
                    System.out.print("Duration: " + duration + " ");
                    System.out.println("\nPlease input any key to continue...");
                    scanner.nextLine();
                    return;

                } // end of duplicate checking
                else {
                    System.out.println("Task not found");

                }
            }
            ;

        } catch (IOException e) {
            System.out.println("Error: File cannot be read");
        }
    }*/
}
