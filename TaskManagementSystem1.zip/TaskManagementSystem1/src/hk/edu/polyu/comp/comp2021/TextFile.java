package hk.edu.polyu.comp.comp2021;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class TextFile extends Print{
    public static void writeFile(String fileName, String string){
        Scanner scanner = new Scanner(System.in);
        String choice = "";
        File file = new File(fileName);

        try {
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String line;
            if (isEmpty(fileName)){
                appendfile(fileName,string);
                reader.close();
                return;
            }
            while ((line = reader.readLine()) != null){
                String[] splitted = line.split("\\|");
                String taskName = splitted[1];
                String writetask = string.split("\\|")[1];

                //if duplicate found
                if (taskName.equals(writetask)) {
                    System.out.println("Duplicate task name found");
                    reader.close();
                    while(choice.isEmpty()){
                        System.out.println("Do you want to overwrite the existing task? (Y/N)");
                        choice = scanner.nextLine();
                        if (choice.toLowerCase().equals("y")){
                            overwrite(fileName,string);
                            return;
                        }else if (choice.toLowerCase().equals("n")){
                            System.out.println("This will not change anything");
                            return;
                        }else{
                            System.out.println("Please input only Y or N");
                            choice = ""; //clear input
                        }
                    }
                }//end of duplicate checking
                else {continue;}
            }addTask(string);

        } catch (IOException e){
            System.out.println("Error: File cannot be read");
        }
    }

    public static void addTask(String string){
        appendfile("Task.txt", string);

    }

    
    public static void appendfile(String fileName, String string){
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, true));
            writer.newLine();
            writer.append(string);

            writer.close();
            System.out.println("Data added successfully");
        } catch (IOException e) {
            System.out.println("File cannot be written");
        }

    }

    public static void overwrite(String fileName, String string){
        try {
            List<String> content = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            String line;
            while ((line = reader.readLine()) != null) {
                content.add(line);
            }

            reader.close();

            // find the duplicate
            String[] stringsplit = string.split("\\|");
            String newtaskName = stringsplit[1];
            int index = -1; // duplicate index
            for (int i = 0; i < content.size(); i++) {
                String[] splitted = content.get(i).split("\\|");
                String oldtaskName = splitted[1];
                if (oldtaskName.equals(newtaskName)) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                content.remove(index);
                content.add(string);
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter(fileName, false)); // append false
            for (String writeline : content) {
                writer.write(writeline);
                writer.newLine();
            }
            writer.close();
            System.out.println("Overwritten");
        } catch (IOException e) {
            System.out.println("File cannot be written");
        }

    }
    public static boolean isEmpty(String fileName){
        try{
            BufferedReader reader = new BufferedReader(new FileReader(fileName));
            if (reader.readLine() == null) {return true;}
            else {return false;}
        }catch (Exception e){
            return true;
        }
    }
    public static void printAll(String fileName){

    }
    /*public static void addCriteria(String taskName, String criteria){
        try {
            List<String> content = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                content.add(line);
            }

            reader.close();

            // find the duplicate
            String[] stringsplit = taskName.split("\\|");
            String newtaskName = stringsplit[0];
            int index = -1; // duplicate index
            for (int i = 0; i < content.size(); i++) {
                String[] splitted = content.get(i).split("\\|");
                String oldtaskName = splitted[0];
                if (oldtaskName.equals(newtaskName)) {
                    index = i;
                    break;
                }
            }
            if (index != -1) {
                String newstring = content.get(index) +"|"+ criteria;

                content.remove(index);
                content.add(newstring);
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter("Task.txt", false)); // append false
            for (String writeline : content) {
                writer.write(writeline);
                writer.newLine();
            }
            writer.close();
            System.out.println("Overwritten");
        } catch (IOException e) {
            System.out.println("File cannot be written");
        }


    }*/

    public static void delCriteria (String taskName, String criteria){
        try {
            List<String> content = new ArrayList<>();
            BufferedReader reader = new BufferedReader(new FileReader("Task.txt"));
            String line;
            while ((line = reader.readLine()) != null) {
                content.add(line);
            }

            reader.close();

            // find the duplicate
            String finalstring = "";
            int index = -1; // duplicate index
            for (int i = 0; i < content.size(); i++) {
                String[] splitted = content.get(i).split("\\|");
                String oldtaskName = splitted[1];
                if (oldtaskName.equals(taskName)) {
                    index = i;
                }

                if (index > -1 &&content.get(index).split("\\|").length < 5) {
                    System.out.println("Error: There are no criteria can be deleted");
                    return;
                } else if (index > -1){
                    int stringindex = -1;
                    int afterstringindex = -1;
                    stringindex = content.get(index).indexOf(criteria);
                    afterstringindex = stringindex + criteria.length();
                    if(stringindex!=-1) {
                        finalstring = content.get(index).substring(0,stringindex-1)+
                                content.get(index).substring(afterstringindex,content.get(index).length());
                    } else {
                        System.out.println("Could not find such criteria");
                        break;
                    }

                }}


            if (index != -1) {
                content.remove(index);
                content.add(finalstring);
                return;
            }

            BufferedWriter writer = new BufferedWriter(new FileWriter("Task.txt", false)); // append false
            for (String writeline : content) {
                writer.write(writeline);
                writer.newLine();
            }
            writer.close();
            System.out.println("Overwritten");
        } catch (IOException e) {
            System.out.println("File cannot be written");
        }


    }

}
